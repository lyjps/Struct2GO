# Supplementary code and results

Companion files for *Testing pLDDT-Guided Fusion for Protein Function Prediction*.
Paths below are relative to the extracted archive root. The branch codes bp, cc,
and mf stand for BPO, CCO, and MFO. Use
[`revision_results/REPRODUCE.md`](revision_results/REPRODUCE.md) for the commands,
environment, and upstream checkpoints.

| Manuscript result | Source files |
| --- | --- |
| Table I, matched GO ablation | `revision_results/{bp,cc,mf}_matched.csv` and `{bp,cc}_fusion_replicates.csv`. Each paired model has three seeds. The sidecars record settings and split counts. |
| Table II, sequence and structure baselines | `revision_results/{bp,cc,mf}_matched.csv`, `mf_deepfri.csv`, `{bp,cc,mf}_full_deepgoplus.json`, and `mf_full_deepfri.json`. |
| Table II, adapted TAWFN | `revision_results/{bp,cc,mf}_tawfn.csv` and matching JSON sidecars. Each branch has one seed. Both gates use the same frozen encoder predictions. |
| Section III.C, GearNet and predicting pLDDT benefit | `revision_results/*_uax_residue_archived_test*.json`, `*_uax_residue_temporal.json`, `*_uax_benefit_experts.json`, and `*_uax_benefit_prediction.json`. Use the archived BPO file with the suffix `_corrected.json`. |
| Tables III and IV, binding residues | `revision_results/binding_confident_sites_complete.json` and `revision_confident_sites.py`. The JSON contains both seeds and the paired group-bootstrap intervals. The archived UniProtKB source, DIAMOND hits, and grouped split and labels are in `.revision-cache/confidence_sites/`. |

`revision_results/RESULTS.md` includes the aggregate GO results.
`revision_results/UAX_RESIDUE_RESULTS.md` and `UAX_BENEFIT_RESULTS.md` describe
the GearNet and benefit-prediction experiments. The latter can be rerun on the
included expert predictions in `.revision-cache/uax_benefit_{bp,cc,mf}/` without
training the experts again. Other result reports document exploratory analyses.

## Inputs for rerunning models

The GO graph runners read the nine processed `new_{branch}_{split}_plddt.pkl`
files from the study workspace. Rerunning the archived GO models requires a copy
of these inputs. The original Struct2GO data source
is [lyjps/Struct2GO](https://github.com/lyjps/Struct2GO/tree/master/divided_data).
The `.revision-cache/expert_{bp,cc,mf}/` folders contain the exact-sequence-filtered
FASTA order and the validation and test DIAMOND alignments to the training split.
The temporal GO label partitions are in `.revision-cache/uax_temporal_go/`.

Obtain the third-party executables, model checkpoints, and AlphaFold coordinates
using the reproduction guide. The large residue embedding and geometry arrays are
generated in `.revision-cache/uax_residues/` and
`.revision-cache/uax_residues_temporal/`. The binding training step builds the
two-seed residue heads from those caches. For exact annotation inputs, use the
archived files in this ZIP and check their hashes in the cohort audit and the
binding result JSON. Use fresh output paths when rerunning experiments.

## Data attribution

- UniProt Consortium, [UniProtKB](https://www.uniprot.org/), release 2026_04
  (November 4, 2026) for the binding-site TSV. The derived split JSON contains
  the selected sequences, residue annotations, and group assignments. UniProtKB
  data are provided under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
- Gene Ontology Consortium, [January 17, 2024](https://release.geneontology.org/2024-01-17/)
  and [July 26, 2026](https://release.geneontology.org/2026-07-26/) releases,
  copyright Gene Ontology Consortium, [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
  The temporal label JSONs are derived from those releases. The
  [GO citation and license page](https://www.geneontology.org/docs/go-citation-policy/)
  includes the data warranty disclaimer.
